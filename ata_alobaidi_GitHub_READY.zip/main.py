
import json
from pathlib import Path
from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import ListProperty, StringProperty
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label

try:
    from plyer import camera
    CAMERA_AVAILABLE = True
except Exception:
    CAMERA_AVAILABLE = False

DATA_FILE = Path(__file__).with_name("products.json")
ADMIN_PASSWORD = "1234"  # غيّرها قبل النشر

class SplashScreen(Screen):
    pass

class HomeScreen(Screen):
    def on_pre_enter(self):
        self.render_products()

    def render_products(self):
        app = App.get_running_app()
        grid = self.ids.product_grid
        grid.clear_widgets()
        for product in app.products:
            from kivy.uix.button import Button
            btn = Button(
                text=f'{product["name"]}\n{product["price"]:,} د.ع',
                font_size="17sp",
                size_hint_y=None,
                height="105dp",
            )
            btn.bind(on_release=lambda _, pid=product["id"]: app.add_to_cart(pid))
            grid.add_widget(btn)

class CartScreen(Screen):
    def on_pre_enter(self):
        self.refresh()

    def refresh(self):
        app = App.get_running_app()
        self.ids.cart_items.text = "\n".join(
            f'• {p["name"]} — {p["price"]:,} د.ع' for p in app.cart
        ) or "السلة فارغة"
        self.ids.cart_total.text = f'المجموع: {app.cart_total():,} د.ع'

class ManagerLoginScreen(Screen):
    def login(self, password):
        if password == ADMIN_PASSWORD:
            self.ids.password.text = ""
            self.manager.current = "manager"
        else:
            self.ids.password.text = ""
            self.ids.message.text = "الرمز غير صحيح"

class ManagerScreen(Screen):
    def on_pre_enter(self):
        self.refresh()

    def refresh(self):
        app = App.get_running_app()
        self.ids.manager_items.clear_widgets()
        from kivy.uix.boxlayout import BoxLayout
        from kivy.uix.label import Label
        from kivy.uix.button import Button
        for p in app.products:
            row = BoxLayout(size_hint_y=None, height=48, spacing=5)
            row.add_widget(Label(text=f'{p["name"]}  |  {p["price"]:,} د.ع'))
            delete = Button(text="حذف", size_hint_x=None, width=70)
            delete.bind(on_release=lambda _, pid=p["id"]: app.delete_product(pid))
            row.add_widget(delete)
            self.ids.manager_items.add_widget(row)

class AddProductScreen(Screen):
    selected_photo = StringProperty("")

    def take_photo(self):
        if not CAMERA_AVAILABLE:
            self.ids.photo_status.text = "الكاميرا ستعمل بعد تثبيت نسخة Android النهائية."
            return
        try:
            target = str(Path(App.get_running_app().user_data_dir) / "new_product.jpg")
            camera.take_picture(filename=target, on_complete=self.photo_done)
        except Exception:
            self.ids.photo_status.text = "تعذر فتح الكاميرا"

    def photo_done(self, path):
        if path:
            self.selected_photo = path
            self.ids.photo_status.text = "تم التقاط الصورة ✓"

    def save_product(self):
        app = App.get_running_app()
        name = self.ids.name.text.strip()
        price_text = self.ids.price.text.strip()
        category = self.ids.category.text.strip() or "عام"

        if not name or not price_text:
            app.show_message("اكتب اسم المنتج والسعر")
            return
        try:
            price = int(price_text)
        except ValueError:
            app.show_message("السعر يجب أن يكون رقمًا")
            return

        new_id = max([p["id"] for p in app.products] or [0]) + 1
        app.products.append({
            "id": new_id,
            "name": name,
            "category": category,
            "price": price,
            "image": self.selected_photo,
        })
        app.save_products()
        self.ids.name.text = ""
        self.ids.price.text = ""
        self.ids.category.text = ""
        self.ids.photo_status.text = "بدون صورة"
        self.selected_photo = ""
        self.manager.current = "manager"

class MarketApp(App):
    products = ListProperty([])
    cart = ListProperty([])

    def build(self):
        self.title = "عطا العبيدي"
        self.products = self.load_products()
        return Builder.load_file("main.kv")

    def on_start(self):
        self.root.current = "splash"
        Clock.schedule_once(lambda *_: self.go_home(), 3.0)

    def go_home(self):
        self.root.current = "home"

    def load_products(self):
        if not DATA_FILE.exists():
            DATA_FILE.write_text(json.dumps(products_default(), ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            return json.loads(DATA_FILE.read_text(encoding="utf-8"))
        except Exception:
            return products_default()

    def save_products(self):
        DATA_FILE.write_text(json.dumps(self.products, ensure_ascii=False, indent=2), encoding="utf-8")

    def add_to_cart(self, product_id):
        product = next((p for p in self.products if p["id"] == product_id), None)
        if product:
            self.cart.append(product.copy())
            self.show_message(f'تمت إضافة {product["name"]} للسلة ✓')

    def cart_total(self):
        return sum(int(p["price"]) for p in self.cart)

    def clear_cart(self):
        self.cart = []
        self.root.get_screen("cart").refresh()

    def delete_product(self, product_id):
        self.products = [p for p in self.products if p["id"] != product_id]
        self.save_products()
        self.root.get_screen("manager").refresh()

    def show_message(self, text):
        Popup(
            title="عطا العبيدي",
            content=Label(text=text),
            size_hint=(0.82, 0.30),
        ).open()

def products_default():
    return [
        {"id": 1, "name": "بيبسي", "category": "مشروبات", "price": 1000, "image": ""},
        {"id": 2, "name": "سفن أب", "category": "مشروبات", "price": 1000, "image": ""},
        {"id": 3, "name": "ميرندا", "category": "مشروبات", "price": 1000, "image": ""},
        {"id": 4, "name": "مياه معدنية", "category": "مشروبات", "price": 500, "image": ""},
        {"id": 5, "name": "چبس", "category": "سناكات", "price": 500, "image": ""},
        {"id": 6, "name": "بسكويت", "category": "سناكات", "price": 500, "image": ""},
        {"id": 7, "name": "رز", "category": "مواد غذائية", "price": 2500, "image": ""},
        {"id": 8, "name": "سكر", "category": "مواد غذائية", "price": 1500, "image": ""},
        {"id": 9, "name": "زيت طبخ", "category": "مواد غذائية", "price": 2500, "image": ""},
        {"id": 10, "name": "شاي", "category": "مواد غذائية", "price": 3000, "image": ""},
        {"id": 11, "name": "حليب", "category": "ألبان", "price": 1500, "image": ""},
        {"id": 12, "name": "جبن", "category": "ألبان", "price": 2000, "image": ""},
        {"id": 13, "name": "مسحوق غسيل", "category": "منظفات", "price": 3500, "image": ""},
        {"id": 14, "name": "صابون", "category": "منظفات", "price": 1000, "image": ""},
    ]

if __name__ == "__main__":
    MarketApp().run()
