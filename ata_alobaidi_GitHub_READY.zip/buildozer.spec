[app]
title = عطا العبيدي
package.name = ataobaidi
package.domain = iq.ataobaidi
source.dir = .
source.include_exts = py,kv,json,jpg,jpeg,png
version = 1.0.0
requirements = python3,kivy,plyer
orientation = portrait
fullscreen = 0
android.permissions = CAMERA
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
